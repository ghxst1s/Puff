just run Puff.exe
and use lunar client 1.8.9 optifine 